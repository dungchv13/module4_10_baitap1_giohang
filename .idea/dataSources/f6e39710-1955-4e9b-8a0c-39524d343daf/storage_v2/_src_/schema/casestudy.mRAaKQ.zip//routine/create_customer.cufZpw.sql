create
    definer = root@localhost procedure create_customer(IN name varchar(50), IN phone int, IN email varchar(50),
                                                       IN address varchar(50), IN cUserName varchar(50),
                                                       IN cPassword varchar(50))
begin
    insert into customers(customerName, customerPhone, customerEmail, customerAddress, userName, password)
    VALUES (name,phone,email,address,cUserName,cPassword);
end;

