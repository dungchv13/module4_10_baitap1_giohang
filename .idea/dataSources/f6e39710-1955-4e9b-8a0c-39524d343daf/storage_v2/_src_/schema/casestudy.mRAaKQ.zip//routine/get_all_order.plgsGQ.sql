create
    definer = root@localhost procedure get_all_order()
begin
    select * from orders;
end;

