create
    definer = root@localhost procedure get_product_by_id(IN id int)
begin
    select * from products where productID = id;
end;

